<?php

namespace App\Providers;

use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Gate;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        // 'App\Model' => 'App\Policies\ModelPolicy',
        // 'App\Post' => 'App\Policies\PostPolicy';
        Post::class => PostPolicy::class
    ];

    /**
     * Register any authentication / authorization services.
     *
     * @return void
     */
    public function boot()
    {
        $this->registerPolicies();

        // Gate::before(function( $user , $abillity , $params ){
        //     if($user->type === 'admin'){
        //         return true;
        //     }
        // });

        // Gate::define('update-post', function ($user, $post) {

        //     if ($post->user_id === $user->id) {
        //         return true;
        //     } else {
        //         return false;
        //     }

        // });

        // Gate::after(function( $user , $abillity, $result , $params ){
        //     // dd( func_get_args() );
        // });
    }
}
