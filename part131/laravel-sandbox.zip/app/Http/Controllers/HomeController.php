<?php

namespace App\Http\Controllers;

use App\Post;
use App\User;
use App\Jobs\TestJob;
use App\Events\CreatePost;
use App\Jobs\TestJobEmail;
use Illuminate\Http\Request;
use App\Notifications\PostPublished;
use App\Notifications\MarkdownNotification;
use Illuminate\Support\Facades\Notification;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $user = User::find(2);

        $post = Post::find(1);

        // TestJob::dispatch();
        // TestJobEmail::dispatch($user)->onQueue('email');
        // TestJobEmail::dispatch($user)->onQueue('email')->delay(now()->addSeconds(20));
        // TestJobEmail::dispatch($user);

        return view('home');

    }

}
