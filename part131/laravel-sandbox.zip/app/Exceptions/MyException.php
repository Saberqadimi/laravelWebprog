<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Support\Facades\Log;

class MyException extends Exception
{
    public function report(){
        // dd( func_get_args() );
        return Log::info('Error ...');
    }

    public function render($request){
        // dd( func_get_args() );
        // return response()->view('error');
    }
}
