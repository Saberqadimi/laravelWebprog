<?php

namespace App\Events;

use App\Post;
use App\User;
use Illuminate\Broadcasting\Channel;
use Illuminate\Queue\SerializesModels;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;

class CreatePost
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    private $user;
    private $post;
    private $id;
    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(User $user, Post $post, $id)
    {
        $this->user = $user;
        $this->post = $post;
        $this->id = $id;
    }

    public function getUser()
    {
        return $this->user;
    }

    public function getPost()
    {
        return $this->post;
    }

    public function getId()
    {
        return $this->id;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('channel-name');
    }
}
