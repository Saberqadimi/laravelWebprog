<?php

namespace App\Mail;

use App\User;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class TestMail extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct(User $user)
    {
        $this->user = $user;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('emails.test')
                ->subject('test email')
                ->replyTo('ali@gmail.com' , 'ali sheikh')
                ->attach(storage_path('app/public/test.txt'))
                ->attach(storage_path('app/public/test1.txt') , [ 'as' => 'ali.txt' ])
                ->to($this->user->email , $this->user->name);
    }
}
