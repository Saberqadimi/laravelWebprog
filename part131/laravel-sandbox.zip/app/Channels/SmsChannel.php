<?php

namespace App\Channels;

use Illuminate\Notifications\Notification;

class SmsChannel
{
    public function send($notifiable, Notification $notification)
    {
        dd( $notifiable , $notification->toSms($notifiable) );

        // Send SMS
    }
}
