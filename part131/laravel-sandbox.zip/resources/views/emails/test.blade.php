<h1 style="color: rebeccapurple;"> Example Email </h1>

<h2 style="font-size: 40px"> {{ $post->title }} </h2>
