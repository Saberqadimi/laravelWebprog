@component('mail::message')
# Introduction

{{ $post->title }}
{{ $post->body }}
The body of your message.

@component('mail::button', ['url' => ''])
Button Text
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
