@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">

        <div class="col-md-8" id="posts">

            <div class="card mb-3">
                <div class="card-header"> Title </div>

                <div class="card-body">
                    <p> 404 Page </p>
                </div>
            </div>

        </div>
    </div>
</div>
@endsection
