<?php

return [
    'welcome' => 'Welcome to :NAME',
    'apples' => '{1}There is one apple|[1,10]There are some apples|[10,*]There are many apples'
];
