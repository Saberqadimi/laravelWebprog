<?php

return [
    'welcome' => 'به :name خوش آمدید',
    'apples' => '{1}یک سیب|[1,10]There are some apples|[10,*]There are many apples'
];
