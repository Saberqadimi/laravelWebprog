<h1 style="color: rebeccapurple;"> Example Email </h1>

<h2 style="font-size: 40px"> <?php echo e($post->title); ?> </h2>
<?php /**PATH C:\Users\webprog\Desktop\laravel-sandbox\resources\views/emails/test.blade.php ENDPATH**/ ?>