[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\Users\webprog\Desktop\laravel-sandbox\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>